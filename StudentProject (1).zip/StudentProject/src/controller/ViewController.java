package controller;

import java.io.File;
import java.net.MalformedURLException;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.print.PrinterJob;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.layout.VBox;
import javafx.stage.Window;
import model.Student;

public class ViewController {
    @FXML
    private ImageView avatarImageView;
    @FXML
    private Label firstNameLabel;
    @FXML
    private Label lastNameLabel;
    @FXML
    private Label emaillabel;
    @FXML
    private Label registrationNumberLabel;
    @FXML
    private Label dateOfBirthLabel;
    @FXML
    private Button printButton;
    @FXML
    private VBox mainContainer;

    public void setStudent(Student student) {
        firstNameLabel.setText(student.getFirstName());
        lastNameLabel.setText(student.getLastName());
        emaillabel.setText(student.getEmail());
        registrationNumberLabel.setText(student.getRegistrationNumber());
        dateOfBirthLabel.setText(student.getDateBirth());
        String avatarFilePath = student.getAvatar();

        try {
            File file = new File(avatarFilePath);
            String fileUrl = file.toURI().toURL().toString();
            Image avatarImage = new Image(fileUrl);
            avatarImageView.setImage(avatarImage);
        } catch (MalformedURLException e) {
            System.out.println("Erreur lors du chargement de l'image : " + e.getMessage());
        }
    }

    @FXML
    private void handlePrintButtonAction(ActionEvent event) {
        Window window = ((Node) event.getSource()).getScene().getWindow();
        PrinterJob printerJob = PrinterJob.createPrinterJob();

        if (printerJob != null && printerJob.showPrintDialog(window)) {
        	// Exclude the button from printing
            printButton.setVisible(false);
            printerJob.printPage(mainContainer);
            printerJob.endJob();
         // Restore the visibility of the button
            printButton.setVisible(true);
        }
    }
}
