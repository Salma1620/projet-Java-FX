package controller;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Screen;
import javafx.stage.Stage;
import model.Student;
import view.Database;

public class UpdateController {
    @FXML
    private TextField firstnameTextField;
    @FXML
    private TextField lastnameTextField;
    @FXML
    private TextField emailTextField;
    @FXML
    private TextField registrationNumberTextField;
    @FXML
    private Label titrelabel;
    @FXML
    private HBox hboxdate;
    @FXML
    private Label lastnameLabel;
    @FXML
    private Label firstnameLabel;
    @FXML
    private Label emailLabel;
    @FXML
    private Label phonelabel;
    @FXML
    private Label birthlabel;
    @FXML
    private Label imageLabel;
    @FXML
    private Spinner<Integer> daySpinner;
    @FXML
    private Spinner<String> monthSpinner;
    @FXML
    private Spinner<Integer> yearSpinner;
    @FXML
    private Button selectimgButton;
    @FXML
    private Button editButton;
    @FXML
    private Text msg;
    @FXML
    private File selectedimg;
    @FXML
    private String selectedImagePath;
    @FXML
    private int selectedid;
    public void initialize() {
        selectimgButton.setOnAction(this::ChangeImage);
        editButton.setOnAction(this::updateStudent);
        daySpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 31, 1));
        
        monthSpinner.setValueFactory(new SpinnerValueFactory.ListSpinnerValueFactory<>(
                FXCollections.observableArrayList(
                		"Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre")
                )
        );

        yearSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1900, 2023, 2000));

    }

    private void ChangeImage(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();        
        File selectedimg = fileChooser.showOpenDialog(selectimgButton.getScene().getWindow());
        selectedImagePath = selectedimg.toString();      
        if (selectedimg != null) {
            selectimgButton.setText("Changer Image");
        }
    }
    
    
    public void setValues (int id,String firstname,String lastname,String email,String phone,int selectedDay,String selectedMonth,int selectedYear,String selectedimg) {
    	firstnameTextField.setText(firstname);
    	lastnameTextField.setText(lastname);
    	emailTextField.setText(email);
    	registrationNumberTextField.setText(phone);
    	daySpinner.getValueFactory().setValue(selectedDay); 
    	monthSpinner.getValueFactory().setValue(selectedMonth); 
    	yearSpinner.getValueFactory().setValue(selectedYear);
    	selectedImagePath=selectedimg;
    	selectedid=id;
    }
    
    
    private void updateStudent(ActionEvent event) {

        String firstname = firstnameTextField.getText();
        String lastname = lastnameTextField.getText();
        String email = emailTextField.getText();
        String registrationNumber = registrationNumberTextField.getText();
        int selectedDay = daySpinner.getValue();
        String selectedMonth = monthSpinner.getValue();
        int selectedYear = yearSpinner.getValue();
        String selectedDate = LocalDate.of(selectedYear, getMonthNumber(selectedMonth), selectedDay).toString();       
        if (firstname.matches("[a-zA-Z\\s]{2,}") && lastname.matches("[a-zA-Z\\s]{2,}")
                &&  email.matches("[a-zA-Z0-9_]+@[a-zA-Z]+.[a-zA-Z]+") && registrationNumber.matches("[0-9]{7}") 
                && selectimgButton.getText().equals("Changer Image")&& (selectedImagePath.matches(".*\\.(jpg|jpeg|png|gif)")) && (selectedDate != null) ) {
        	try {

       	     Connection connection = Database.getConnection();
       	     String query = "UPDATE student SET email = ?, firstname = ?, lastname = ?, registrationNumber= ?,dateBirth= ? , avatar = ? WHERE id = ?";

       	     PreparedStatement statement = connection.prepareStatement(query);
       	     statement.setString(1, email);
       	     statement.setString(2, firstname);
       	     statement.setString(3, lastname);
       	     statement.setString(4, registrationNumber);
       	     statement.setString(5, selectedDate);
       	     statement.setString(6, selectedImagePath);
       	     statement.setInt(7, selectedid);
       	     statement.executeUpdate();
       	     statement.close();
       	     connection.close();
       	     msg=null;
       	     firstnameTextField.clear();
             lastnameTextField.clear();
             emailTextField.clear();
             registrationNumberTextField.clear();
             goToTable();
             

       	     } catch (SQLException ex) {
       	            System.out.println("SQLException: " + ex.getMessage());
       	     }
        	
        	
        	
        	
        }else {
            if (!firstname.matches("[a-zA-Z\\s]{2,}")) {
                msg.setText("Veuillez Introduire un Prénom ");
            } else if (!lastname.matches("[a-zA-Z\\s]{2,}")) {
                msg.setText("Veuillez Introduire un Nom");
            } else if (!email.matches("[a-zA-Z0-9_]+@[a-zA-Z]+.[a-zA-Z]+")) {
                msg.setText("Veuillez Introduire un Email");
            } else if (!registrationNumber.matches("[0-9]{7}")) {
                msg.setText("Veuillez Introduire un Numéro d'Inscription ");
            } else if (selectimgButton.getText().equals("choisir Image") || (!selectedImagePath.matches(".*\\.(jpg|jpeg|png|gif)"))) {
                msg.setText("Veuillez Choisir Une Image");
            }
        }
        event.consume();
    }

  
    private int getMonthNumber(String monthName) {
        switch (monthName) {
        case "Janvier":
            return 1;
        case "Février":
            return 2;
        case "Mars":
            return 3;
        case "Avril":
            return 4;
        case "Mai":
            return 5;
        case "Juin":
            return 6;
        case "Juillet":
            return 7;
        case "Août":
            return 8;
        case "Septembre":
            return 9;
        case "Octobre":
            return 10;
        case "Novembre":
            return 11;
        case "Décembre":
            return 12;
            default:
                return 0;
        }
    
    }
    @FXML
    private void goToTable() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/fxml/Table.fxml"));
            Parent tableRoot = loader.load();
            Scene table = new Scene(tableRoot);
            // Modifier les dimensions de la deuxième scène selon vos besoins
            Stage primaryStage = (Stage) editButton.getScene().getWindow();
            double sceneWidth = 1300;
            double sceneHeight = 680;
            table.getStylesheets().add(getClass().getResource("../css/application.css").toExternalForm());

            primaryStage.setWidth(sceneWidth);
            primaryStage.setHeight(sceneHeight);

            // Centrer la fenêtre sur l'écran
            double screenWidth = Screen.getPrimary().getVisualBounds().getWidth();
            double screenHeight = Screen.getPrimary().getVisualBounds().getHeight();
            primaryStage.setX((screenWidth - sceneWidth) / 2);
            primaryStage.setY((screenHeight - sceneHeight) / 2);
            
            primaryStage.setScene(table);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}