package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import model.Student;
import view.Database;
import java.time.LocalDate;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import controller.UpdateController;
import controller.ViewController;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;


import java.io.IOException;

public class Controller {

    @FXML
    private TableView<Student> tableView;
    @FXML
    private TableColumn<Student, Button> deleteColumn;
    @FXML
    private TableColumn<Student, Button> updateColumn;
    @FXML
    private TableColumn<Student, Button> viewColumn;
    @FXML
    private TableColumn<Student, String> firstNameColumn;
    @FXML
    private TableColumn<Student, String> lastNameColumn;
    @FXML
    private TableColumn<Student, String> emailColumn;
    @FXML
    private TableColumn<Student, String> registrationNumberColumn;
    @FXML
    private TableColumn<Student, String> dateColumn;
    @FXML
    private TableColumn<Student, String> avatarColumn;
    @FXML
    private Button addstudentButton;
    @FXML
    private String supprimer="supprimer";

    public void initialize() {
        deleteColumn.setCellValueFactory(new PropertyValueFactory<>("deleteButton"));
        updateColumn.setCellValueFactory(new PropertyValueFactory<>("updateButton"));
        viewColumn.setCellValueFactory(new PropertyValueFactory<>("viewButton"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        registrationNumberColumn.setCellValueFactory(new PropertyValueFactory<>("registrationNumber"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("dateBirth"));
        avatarColumn.setCellValueFactory(new PropertyValueFactory<>("avatar"));
        avatarColumn.setResizable(false);
        loadStudentsFromDatabase();
    }
    
    private void loadStudentsFromDatabase() {
        ObservableList<Student> students = FXCollections.observableArrayList();

        try {
            Connection connection = Database.getConnection();
            String query = "SELECT * FROM student ORDER BY lastName ASC";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String firstName = resultSet.getString("firstName");
                String lastName = resultSet.getString("lastName");
                String email = resultSet.getString("email");
                String registrationNumber = resultSet.getString("registrationNumber");
                String dateBirth = resultSet.getString("dateBirth");
                
                DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                LocalDate localDate = LocalDate.parse(dateBirth, inputFormatter);

                DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                dateBirth = localDate.format(outputFormatter);
                String avatar = resultSet.getString("avatar");

                Button deleteButton = new Button("Supprimer");
                Button updateButton = new Button("Modifier");
                Button viewButton = new Button("Profil");

                Student student = new Student(id, email, lastName, firstName, registrationNumber, dateBirth, avatar);
                student.setDeleteButton(deleteButton);
                student.setUpdateButton(updateButton);
                student.setViewButton(viewButton);
                students.add(student);

                // Delete Event
                deleteButton.setOnAction(event -> {
                    deleteStudentFromDatabase(student);
                    if(supprimer=="supprimer") {
                        students.remove(student);
                    }
                    supprimer="supprimer";
                });

             // Update Event
                updateButton.setOnAction(event -> {
                    goToUpdateScene(student);
                });

                // View Event
                viewButton.setOnAction(event -> {
                    goToViewScene(student);
                });

            }

            resultSet.close();
            statement.close();
            connection.close();

        } catch (SQLException ex) {
            System.out.println("SQLException: " + ex.getMessage());
        }

        tableView.setItems(students);
    }

    @FXML
    private void deleteStudentFromDatabase(Student student) {
    	Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText("Confirmation de la suppression");
        alert.setContentText("Voulez-vous vraiment supprimer l'étudiant ?");
        ButtonType deleteButton = new ButtonType("Supprimer");
        ButtonType cancelButton = new ButtonType("Annuler");
        alert.getButtonTypes().setAll(deleteButton, cancelButton);
        alert.showAndWait().ifPresent(response -> {
            if (response == deleteButton) {
            	try {
            		Connection connection = Database.getConnection();
            		String query = "DELETE FROM student WHERE id = ?";
            		PreparedStatement statement = connection.prepareStatement(query);
            		statement.setInt(1, student.getId());
            		statement.executeUpdate();
		            statement.close();
		            connection.close();
		 
		        }catch (SQLException ex) {
		            System.out.println("SQLException: " + ex.getMessage());
		        }
            }
		        else {
		            	supprimer="annuler";
		        }
        });
    }

    @FXML
    private void goToAddScene(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/fxml/AddScene.fxml"));
            Parent addSceneRoot = loader.load();
            Scene addScene = new Scene(addSceneRoot);
            // Modifier les dimensions de la deuxième scène selon vos besoins
            Stage primaryStage = (Stage) addstudentButton.getScene().getWindow();
            double sceneWidth = 700;
            double sceneHeight = 650;
            addScene.getStylesheets().add(getClass().getResource("../css/application.css").toExternalForm());

            primaryStage.setWidth(sceneWidth);
            primaryStage.setHeight(sceneHeight);

            // Centrer la fenêtre sur l'écran
            double screenWidth = Screen.getPrimary().getVisualBounds().getWidth();
            double screenHeight = Screen.getPrimary().getVisualBounds().getHeight();
            primaryStage.setX((screenWidth - sceneWidth) / 2);
            primaryStage.setY((screenHeight - sceneHeight) / 2);
            
            primaryStage.setScene(addScene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    private void goToUpdateScene(Student selectedStudent) {
        try {

            if (selectedStudent != null) {
            	FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/fxml/UpdateScene.fxml"));
            	 Parent UpdateSceneRoot = loader.load();
                 Scene UpdateScene = new Scene(UpdateSceneRoot);
                 UpdateScene.getStylesheets().add(getClass().getResource("../css/application.css").toExternalForm());

    	        // Afficher les valeurs de l'élément sélectionné dans les champs de saisie
            	String firstname=selectedStudent.getFirstName();
            	String lastname=selectedStudent.getLastName();
            	String email=selectedStudent.getEmail();
                String registrationNumber = selectedStudent.getRegistrationNumber();
    	        String ageField=selectedStudent.getDateBirth();
    	        String[] partofdate = ageField.split("/");
    	        int selectedDay = Integer.parseInt(partofdate[0]);
    	        String selectedMonth = getMonthName(Integer.parseInt(partofdate[1]));
    	        int selectedYear = Integer.parseInt(partofdate[2]);
    	        String selectedimg=selectedStudent.getAvatar();
    	        int selectedid=selectedStudent.getId();
    	        //System.out.print(firstname);
    	        UpdateController UpdateController = loader.getController();
                UpdateController.setValues(selectedid, firstname, lastname, email, registrationNumber, selectedDay, selectedMonth, selectedYear, selectedimg);
    	           
                // Modifier les dimensions de la deuxième scène selon vos besoins
                Stage primaryStage = (Stage) addstudentButton.getScene().getWindow();
                double sceneWidth = 700;
                double sceneHeight = 650;

                primaryStage.setWidth(sceneWidth);
                primaryStage.setHeight(sceneHeight);

                // Centrer la fenêtre sur l'écran
                double screenWidth = Screen.getPrimary().getVisualBounds().getWidth();
                double screenHeight = Screen.getPrimary().getVisualBounds().getHeight();
                primaryStage.setX((screenWidth - sceneWidth) / 2);
                primaryStage.setY((screenHeight - sceneHeight) / 2);

                primaryStage.setScene(UpdateScene);
                primaryStage.show();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void goToViewScene(Student student) {
        try {
        	FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/fxml/ViewScene.fxml"));
            Parent viewSceneRoot = loader.load();
            Scene viewScene = new Scene(viewSceneRoot,550,500);
            viewScene.getStylesheets().add(getClass().getResource("../css/application.css").toExternalForm());        
            

            // Obtenir le contrôleur de la vue
            ViewController viewController = loader.getController();
            // Passer l'objet Student à la méthode setStudent() du contrôleur
            viewController.setStudent(student);

            Stage primaryStage = new Stage();
            
            primaryStage.setScene(viewScene);
            Image icon = new Image(getClass().getResource("../images/etudiant-avec-bonnet-de-graduation.png").toExternalForm());
    		primaryStage.getIcons().add(icon);
            primaryStage.setTitle("Profil Etudiant ");
            primaryStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getMonthName(int monthNumber) {
        switch (monthNumber) {
        case 1:
            return "Janvier";
        case 2:
            return "Février";
        case 3:
            return "Mars";
        case 4:
            return "Avril";
        case 5:
            return "Mai";
        case 6:
            return "Juin";
        case 7:
            return "Juillet";
        case 8:
            return "Août";
        case 9:
            return "Septembre";
        case 10:
            return "Octobre";
        case 11:
            return "Novembre";
        case 12:
            return "Décembre";
            default:
                return "";
        }
    }
    

}