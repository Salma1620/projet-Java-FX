package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Main extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("fxml/Table.fxml"));
		Parent root = loader.load();
		root.getStylesheets().add(getClass().getResource("../css/application.css").toExternalForm());        
         
        Scene scene = new Scene(root, 1280, 645);
        
        Image icon = new Image(getClass().getResource("../images/téléchargement (4).png").toExternalForm());
		primaryStage.getIcons().add(icon);

        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.setTitle("Etudiants ENSAO ");
        primaryStage.show();
	}
	
	
	public static void main(String[] args) {
		launch(args);
	}
}